package capolavororeal;

import java.io.*;
import java.util.*;

/**
 * Gioco del TRIS
 */
public class CapolavoroReal {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Scanner kb = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        String Giocatore1 = "";
        String Giocatore2 = "";
        String Risposta1 = "";
        String Risposta2 = "";
        char rispostaStringa = 0;
        char rispostaStringa2 = 's';
        String[] riga1 = new String[3];
        String[] riga2 = new String[3];
        String[] riga3 = new String[3];
        int mosse = 1;
        int r1c1 = 0;
        int r1c2 = 0;
        int r1c3 = 0;
        int r2c1 = 0;
        int r2c2 = 0;
        int r2c3 = 0;
        int r3c1 = 0;
        int r3c2 = 0;
        int r3c3 = 0;
        int vittorie1 = 0;
        int vittorie2 = 0;
        int vittorieEND = 0;
        
        for (int i = 0; i < 3; i++) {
            riga1[i] = " ";
            riga2[i] = " ";
            riga3[i] = " ";
        }
        System.out.println(" Gioco del TRIS: ");
        System.out.println(" ");
        System.out.println("      |    |        R1 ");
        System.out.println(" ---------------- ");
        System.out.println("      |    |        R2 ");
        System.out.println(" ---------------- ");
        System.out.println("      |    |        R3 ");
        System.out.println(" ");
        System.out.println("  C1    C2    C3 ");

        System.out.println(" ");

                vittorieEND = vittorie1+vittorie2;
                
                System.out.print(" Giocatore 1, inserisci il tuo nome: ");
                Giocatore1 = kb.nextLine();
                System.out.println(" ");
                System.out.print(" Giocatore 2, inserisci il tuo nome: ");
                Giocatore2 = kb.nextLine();
                while (rispostaStringa2 == 's'){
                    System.out.println(" ");
                System.out.println(" Adesso verrà scelto casualmente chi inizierà per primo tra voi due. ");
                int generatore = random.nextInt(2) + 1;
                switch (generatore) {
                    case 1:
                        System.out.println(" ");
                        System.out.println(" E' stato selezionato: " + Giocatore1 + ", inizierai tu. ");
                        System.out.println(" ");
                        System.out.print(" "+ Giocatore1 +" scegli se voler utilizzare X oppure O come tue 'pedine': ");
                        rispostaStringa = sc.next().toLowerCase().charAt(0);
                        while (rispostaStringa != 'x' && rispostaStringa != 'o') {
                            System.out.println(" ----------------------------------- ");
                            System.out.println(" ");
                            System.out.println(" Selezione non valida: ");
                            System.out.println(" Inserire X se si vogliono utillare le X. ");
                            System.out.println(" Inserire O (lettera O) se si vogliono utilizzare le O. ");
                            System.out.print(" Fare la propria scelta: ");
                            rispostaStringa = sc.next().toLowerCase().charAt(0);
                        }
                        switch (rispostaStringa) {
                            case 'x':
                                System.out.println(" ");
                                System.out.println(" " + Giocatore1 + " Hai selezionato le X. ");
                                System.out.println(" ");
                                System.out.println("        |      |        R1 (RIGA 1) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R2 (RIGA 2) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R3 (RIGA 3) ");
                                System.out.println(" ");
                                System.out.println("     C1    C2    C3  ");
                                System.out.println(" (COLONNA1) (COLONNA2) COLONNA3)");
                                System.out.println(" ");
                                while (mosse <= 9) {
                                    if (mosse % 2 != 0) {
                                        System.out.print(" " + Giocatore1 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                           
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;

                                        }
                                    } else {
                                        System.out.print(" " + Giocatore2 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");
                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }
                                                        break;
                                                        
                                                    case "c3":
                                                        
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        
                                                        break;
                                                }
                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                            
                                        }

                                    }
                                }
                                
                                break;
                                
                            case 'o':
                                System.out.println(" ");
                                System.out.println(" " + Giocatore1 + " Hai selezionato le O. ");
                                System.out.println(" ");
                                System.out.println("        |      |        R1 (RIGA 1) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R2 (RIGA 2) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R3 (RIGA 3) ");
                                System.out.println(" ");
                                System.out.println("     C1    C2    C3  ");
                                System.out.println(" (COLONNA1) (COLONNA2) COLONNA3)");
                                System.out.println(" ");
                                while (mosse <= 9) {
                                    if (mosse % 2 != 0) {
                                        System.out.print(" " + Giocatore1 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                           
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;

                                        }
                                    } else {
                                        System.out.print(" " + Giocatore2 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");
                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }
                                                        break;
                                                        
                                                    case "c3":
                                                        
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        
                                                        break;
                                                }
                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                            
                                        }

                                    }
                                }
                                
                                break;

                        }
                        
                        break;
                        
                    case 2:
                        System.out.println(" ");
                        System.out.println(" E' stato selezionato: " + Giocatore2 + ", inizierai tu. ");
                        System.out.println(" ");
                        System.out.print(" "+ Giocatore2 +" scegli se voler utilizzare X oppure O come tue 'pedine': ");
                        rispostaStringa = sc.next().toLowerCase().charAt(0);
                        while (rispostaStringa != 'x' && rispostaStringa != 'o') {
                            System.out.println(" ----------------------------------- ");
                            System.out.println(" ");
                            System.out.println(" Selezione non valida: ");
                            System.out.println(" Inserire X se si vogliono utillare le X. ");
                            System.out.println(" Inserire O (lettera O) se si vogliono utilizzare le O. ");
                            System.out.print(" Fare la propria scelta: ");
                            rispostaStringa = sc.next().toLowerCase().charAt(0);
                        }
                        switch (rispostaStringa) {
                            case 'x':
                                System.out.println(" ");
                                System.out.println(" " + Giocatore2 + " Hai selezionato le X. ");
                                System.out.println(" ");
                                System.out.println("        |      |        R1 (RIGA 1) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R2 (RIGA 2) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R3 (RIGA 3) ");
                                System.out.println(" ");
                                System.out.println("     C1    C2    C3  ");
                                System.out.println(" (COLONNA1) (COLONNA2) COLONNA3)");
                                System.out.println(" ");
                                while (mosse <= 9) {
                                    if (mosse % 2 != 0) {
                                        System.out.print(" " + Giocatore2 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                           
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;

                                        }
                                    } else {
                                        System.out.print(" " + Giocatore1 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");
                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }
                                                        break;
                                                        
                                                    case "c3":
                                                        
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        
                                                        break;
                                                }
                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                    System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece , dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                            
                                        }

                                    }
                                }
                                
                                break;
                                
                            case 'o':
                                System.out.println(" ");
                                System.out.println(" " + Giocatore2 + " Hai selezionato le O. ");
                                System.out.println(" ");
                                System.out.println("        |      |        R1 (RIGA 1) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R2 (RIGA 2) ");
                                System.out.println("   ------------------ ");
                                System.out.println("        |      |        R3 (RIGA 3) ");
                                System.out.println(" ");
                                System.out.println("     C1    C2    C3  ");
                                System.out.println(" (COLONNA1) (COLONNA2) COLONNA3)");
                                System.out.println(" ");
                                while (mosse <= 9) {
                                    if (mosse % 2 != 0) {
                                        System.out.print(" " + Giocatore2 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                           
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga1[1] == "O" && riga1[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece , dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "O" && riga2[1] == "O" && riga2[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore2 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "O";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "O" && riga2[1] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[0] == "O" && riga3[0] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            
                                                            
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "O";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "O" && riga2[1] == "O" && riga3[1] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore2 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "O";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "O" && riga3[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "O" && riga2[2] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "O" && riga2[1] == "O" && riga3[2] == "O"){
                                                                mosse = 10;
                                                                vittorie2++;
                                                                System.out.println(" Congratulazioni "+ Giocatore2 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;

                                        }
                                    } else {
                                        System.out.print(" " + Giocatore1 + ", selezionare la riga in cui si vuole collocare la propria 'pedina' (R1, R2, R3): ");
                                        Risposta1 = kb.next().toLowerCase();

                                        while (!Risposta1.equals("r1") && !Risposta1.equals("r2") && !Risposta1.equals("r3")) {
                                            System.out.println(" ");
                                            System.out.print(" Scelta non valida, inserire R1, R2 o R3: ");
                                            Risposta1 = kb.next().toLowerCase();
                                        }
                                        switch (Risposta1.toLowerCase()) {
                                            case "r1":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la prima riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r1c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c1 = 1;
                                                            riga1[0] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore1 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");
                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r1c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c2 = 1;
                                                            riga1[1] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }
                                                        break;
                                                        
                                                    case "c3":
                                                        
                                                        if (r1c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r1c3 = 1;
                                                            riga1[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga1[1] == "X" && riga1[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        
                                                        break;
                                                }
                                                break;
                                                
                                                case "r2":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la seconda riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r2c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c1 = 1;
                                                            riga2[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r2c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c2 = 1;
                                                            riga2[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r2c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r2c3 = 1;
                                                            riga2[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga2[0] == "X" && riga2[1] == "X" && riga2[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                                case "r3":
                                                System.out.println(" ");
                                                System.out.print(" " + Giocatore1 + ", hai scelto la terza riga, ora selezionare la colonna (C1, C2, C3): ");
                                                Risposta1 = kb.next().toLowerCase();
                                                if (!Risposta1.equals("c1") && !Risposta1.equals("c2") && !Risposta1.equals("c3")){
                                                    System.out.println(" ");
                                                    System.out.println(" Seleziona non valida, rifare la propria mossa. ");
                                                    System.out.println(" ");
                                                }
                                                switch (Risposta1.toLowerCase()) {
                                                    case "c1":
                                                        if (r3c1 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la prima colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c1 = 1;
                                                            riga3[0] = "X";
                                                            System.out.println("");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga1[2] == "X" && riga2[1] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[0] == "X" && riga3[0] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c2":
                                                        if (r3c2 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la seconda colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c2 = 1;
                                                            riga3[1] = "X";
                                                            System.out.println(" ");
                                                           System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[1] == "X" && riga2[1] == "X" && riga3[1] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                    case "c3":
                                                        if (r3c3 == 0) {
                                                            System.out.println(" ");
                                                            System.out.println(" " + Giocatore1 + ", hai scelto la terza colonna, la tua mossa e' stata effetuata. ");
                                                            mosse++;
                                                            r3c3 = 1;
                                                            riga3[2] = "X";
                                                            System.out.println(" ");
                                                            System.out.println("    " + riga1[0] + "  |  " + riga1[1] + "   |  " + riga1[2] + "    R1 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga2[0] + "  |  " + riga2[1] + "   |  " + riga2[2] + "    R2 ");
                                                            System.out.println(" ------------------- ");
                                                            System.out.println("    " + riga3[0] + "  |  " + riga3[1] + "   |  " + riga3[2] + "    R3 ");
                                                            System.out.println(" ");
                                                            System.out.println("    C1    C2    C3 ");
                                                            System.out.println(" ");
                                                            if (riga3[0] == "X" && riga3[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[2] == "X" && riga2[2] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                            if (riga1[0] == "X" && riga2[1] == "X" && riga3[2] == "X"){
                                                                mosse = 10;
                                                                vittorie1++;
                                                                System.out.println(" Congratulazioni "+ Giocatore1 + ", hai vinto il gioco del TRIS. ");
                                                                System.out.println(" ");
                                                                System.out.println(" "+ Giocatore2 + ", mi dispiace per te invece ma hai perso, dovevi stare più attento, andra' meglio la prossima volta. ");
                                                                System.out.println("");
                                                                System.out.println(" Vittorie di "+ Giocatore1 + ": "+vittorie1);
                                                                System.out.println(" ");
                                                                System.out.println(" Vittorie di "+ Giocatore2 + ": "+vittorie2);
                                                                System.out.println(" ");
                                                                break;
                                                            }
                                                        } else {
                                                            System.out.println(" ");
                                                            System.out.println(" Questa posizione e' gia' stata selezionata, rifare la propria mossa. ");
                                                            System.out.println(" ");

                                                        }

                                                        break;

                                                }

                                                break;
                                                
                                            
                                        }

                                    }
                                }
                                
                                break;

                    }

                    break;

            }
                    if (vittorieEND == vittorie1 + vittorie2) {
                        System.out.println(" La partita è finita in pareggio, nessuno ha fatto TRIS. ");
                        System.out.println(" ");
                        System.out.println(" Vittorie di " + Giocatore1 + ": " + vittorie1);
                        System.out.println(" ");
                        System.out.println(" Vittorie di " + Giocatore2 + ": " + vittorie2);
                        System.out.println(" ");
                    }
                    else{
                        vittorieEND = vittorie1 + vittorie2;
                    }
            System.out.println(" ----------------------------------------- ");
            System.out.println(" ");
            System.out.print(" " + Giocatore1 + " e " + Giocatore2 + " Volete giocare ancora: SI (s), NO (n), fare la propria scelta: ");
            rispostaStringa2 = sc.next().toLowerCase().charAt(0);
            if (rispostaStringa2 == 's') {
                mosse = 1;
                for (int i = 0; i < 3; i++) {
                    riga1[i] = " ";
                    riga2[i] = " ";
                    riga3[i] = " ";
                    r1c1 = 0;
                    r1c2 = 0;
                    r1c3 = 0;
                    r2c1 = 0;
                    r2c2 = 0;
                    r2c3 = 0;
                    r3c1 = 0;
                    r3c2 = 0;
                    r3c3 = 0;
                }
            }
            System.out.println(" ");
        }


         

    }

}
